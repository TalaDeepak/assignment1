import { Button, Slider } from "@mui/material";
import { useState } from "react";

function Settings() {
  const [slider, setSlider] = useState(10);
  const marks = [
    {
      value: 5,
      label: "500 credits",
    },
    {
      value: 10,
      label: "1200 credits",
    },
    {
      value: 15,
      label: "1700 credits",
    },
    {
      value: 20,
      label: "2500 credits",
    },
    {
      value: 25,
      label: "3900 credits",
    },
    {
      value: 30,
      label: "5000 credits",
    },
  ];

  function handleButtonClick() {
    const val = marks.filter((item) => item.value === slider);
    alert(`You have selected ${val[0].label}`);
    console.log(val[0].label);
  }

  function handleSliderChange(e) {
    setSlider(e.target.value);
  }

  return (
    <div>
      <div>
        <Slider
          color="primary"
          defaultValue={10}
          max={30}
          min={5}
          marks={marks}
          value={slider}
          valueLabelDisplay="auto"
          onChange={handleSliderChange}
        />
      </div>
      <Button variant="contained" color="success" onClick={handleButtonClick}>
        Confirm auto&ndash;purchase
      </Button>
    </div>
  );
}

export default Settings;
