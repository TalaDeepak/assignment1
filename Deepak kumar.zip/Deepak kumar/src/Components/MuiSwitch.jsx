import { Box, FormControlLabel, Switch, Typography } from "@mui/material";
import { useState } from "react";
import Settings from "./Settings";

function MuiSwitch() {
  const [checked, setChecked] = useState(true);

  function handleChange(e) {
    setChecked(e.target.checked);
  }

  return (
    <Box>
      <FormControlLabel
        label="Setup Auto Top-up "
        control={
          <Switch
            color="success"
            checked={checked}
            onChange={handleChange}
            size="medium"
          />
        }
      />
      <Typography variant="h6">
        Once the credit goes below a minimum threshold 50, we will auto-purchase
        1200 credits and add them to your account
      </Typography>
      {checked && <Settings></Settings>}
    </Box>
  );
}

export default MuiSwitch;
