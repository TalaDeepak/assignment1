import "./App.css";
import MuiSwitch from "./Components/MuiSwitch";

function App() {
  return (
    <>
      <MuiSwitch />
    </>
  );
}

export default App;
